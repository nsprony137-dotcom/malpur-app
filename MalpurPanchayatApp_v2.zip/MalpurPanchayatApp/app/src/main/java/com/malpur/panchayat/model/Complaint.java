package com.malpur.panchayat.model;

public class Complaint {
    private String title;
    private String details;
    private String location;
    private String status;
    private boolean isConfidential;

    public Complaint() {}

    public Complaint(String title, String details, String location, String status, boolean isConfidential) {
        this.title = title;
        this.details = details;
        this.location = location;
        this.status = status;
        this.isConfidential = isConfidential;
    }

    public String getTitle() { return title; }
    public String getDetails() { return details; }
    public String getLocation() { return location; }
    public String getStatus() { return status; }
    public boolean isConfidential() { return isConfidential; }
}
