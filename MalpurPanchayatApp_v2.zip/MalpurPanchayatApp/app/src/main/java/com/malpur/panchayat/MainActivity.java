package com.malpur.panchayat;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText etTitle, etDetails, etLocation;
    private CheckBox cbConfidential;
    private Button btnSubmit;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = FirebaseFirestore.getInstance();

        etTitle = findViewById(R.id.etTitle);
        etDetails = findViewById(R.id.etDetails);
        etLocation = findViewById(R.id.etLocation);
        cbConfidential = findViewById(R.id.cbConfidential);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitComplaint();
            }
        });
    }

    private void submitComplaint() {
        String title = etTitle.getText().toString().trim();
        String details = etDetails.getText().toString().trim();
        String location = etLocation.getText().toString().trim();
        boolean isConfidential = cbConfidential.isChecked();

        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(details)) {
            Toast.makeText(this, "कृपया शिकायत का शीर्षक एवं विवरण भरें", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> complaint = new HashMap<>();
        complaint.put("title", title);
        complaint.put("details", details);
        complaint.put("location", location);
        complaint.put("isConfidential", isConfidential);
        complaint.put("status", "Pending");
        complaint.put("timestamp", System.currentTimeMillis());

        db.collection("complaints").add(complaint);

        Toast.makeText(this, "आपकी शिकायत दर्ज कर ली गई है!", Toast.LENGTH_LONG).show();
        etTitle.setText("");
        etDetails.setText("");
        etLocation.setText("");
        cbConfidential.setChecked(false);
    }
}
