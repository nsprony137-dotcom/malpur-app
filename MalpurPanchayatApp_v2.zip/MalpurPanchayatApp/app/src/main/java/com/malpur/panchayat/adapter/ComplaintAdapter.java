package com.malpur.panchayat.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.malpur.panchayat.R;
import.malpur.panchayat.model.Complaint;
import java.util.List;

public class ComplaintAdapter extends RecyclerView.Adapter<ComplaintAdapter.ViewHolder> {

    private List<Complaint> list;

    public ComplaintAdapter(List<Complaint> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_complaint, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Complaint complaint = list.get(position);
        holder.tvTitle.setText(complaint.getTitle());
        holder.tvDetails.setText(complaint.getDetails());
        holder.tvLocation.setText("स्थान: " + complaint.getLocation());
        holder.tvStatus.setText("स्थिति: " + complaint.getStatus());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvDetails, tvLocation, tvStatus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvItemTitle);
            tvDetails = itemView.findViewById(R.id.tvItemDetails);
            tvLocation = itemView.findViewById(R.id.tvItemLocation);
            tvStatus = itemView.findViewById(R.id.tvItemStatus);
        }
    }
}
