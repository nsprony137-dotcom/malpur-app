package com.malpur.panchayat;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.malpur.panchayat.adapter.ComplaintAdapter;
import com.malpur.panchayat.model.Complaint;
import java.util.ArrayList;
import java.util.List;

public class AdminDashboardActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ComplaintAdapter adapter;
    private List<Complaint> complaintList;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        recyclerView = findViewById(R.id.recyclerViewAdmin);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        complaintList = new ArrayList<>();
        adapter = new ComplaintAdapter(complaintList);
        recyclerView.setAdapter(adapter);

        db = FirebaseFirestore.getInstance();

        loadComplaints();
    }

    private void loadComplaints() {
        db.collection("complaints").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                complaintList.clear();
                for (QueryDocumentSnapshot doc : task.getResult()) {
                    Complaint complaint = doc.toObject(Complaint.class);
                    complaintList.add(complaint);
                }
                adapter.notifyDataSetChanged();
            } else {
                Toast.makeText(AdminDashboardActivity.this, "डेटा लोड करने में विफल", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
